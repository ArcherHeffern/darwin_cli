package test.test1;

public class Algo {
    public static int fibIter(int target) {
        if (target == 1) {
            return 0;
        }
        int prev = 0;
        int sum = 1;
        int temp;
        for (int i = 2; i < target; i++) {
            temp = sum;
            sum = sum + prev;
            prev = temp;
        }
        return sum;
    }
}